﻿namespace Products
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnChips = new System.Windows.Forms.Button();
            this.btnCola = new System.Windows.Forms.Button();
            this.btnCandy = new System.Windows.Forms.Button();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.txtMoney = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPay = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnChips
            // 
            this.btnChips.Location = new System.Drawing.Point(364, 27);
            this.btnChips.Name = "btnChips";
            this.btnChips.Size = new System.Drawing.Size(80, 42);
            this.btnChips.TabIndex = 0;
            this.btnChips.Text = "Chips - $0.50";
            this.btnChips.UseVisualStyleBackColor = true;
            this.btnChips.Click += new System.EventHandler(this.btnChips_Click);
            // 
            // btnCola
            // 
            this.btnCola.Location = new System.Drawing.Point(252, 27);
            this.btnCola.Name = "btnCola";
            this.btnCola.Size = new System.Drawing.Size(92, 42);
            this.btnCola.TabIndex = 1;
            this.btnCola.Text = "Cola - $1.00";
            this.btnCola.UseVisualStyleBackColor = true;
            this.btnCola.Click += new System.EventHandler(this.btnCola_Click);
            // 
            // btnCandy
            // 
            this.btnCandy.Location = new System.Drawing.Point(466, 27);
            this.btnCandy.Name = "btnCandy";
            this.btnCandy.Size = new System.Drawing.Size(80, 42);
            this.btnCandy.TabIndex = 2;
            this.btnCandy.Text = "Candy - $0.65";
            this.btnCandy.UseVisualStyleBackColor = true;
            this.btnCandy.Click += new System.EventHandler(this.btnCandy_Click);
            // 
            // lblDisplay
            // 
            this.lblDisplay.AutoSize = true;
            this.lblDisplay.ForeColor = System.Drawing.Color.Red;
            this.lblDisplay.Location = new System.Drawing.Point(249, 195);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(46, 17);
            this.lblDisplay.TabIndex = 3;
            this.lblDisplay.Text = "label1";
            // 
            // txtMoney
            // 
            this.txtMoney.Location = new System.Drawing.Point(252, 109);
            this.txtMoney.Name = "txtMoney";
            this.txtMoney.Size = new System.Drawing.Size(192, 22);
            this.txtMoney.TabIndex = 4;
       
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(249, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enter the money:";
            // 
            // btnPay
            // 
            this.btnPay.Location = new System.Drawing.Point(252, 137);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(75, 23);
            this.btnPay.TabIndex = 6;
            this.btnPay.Text = "PAY";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMoney);
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.btnCandy);
            this.Controls.Add(this.btnCola);
            this.Controls.Add(this.btnChips);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnChips;
        private System.Windows.Forms.Button btnCola;
        private System.Windows.Forms.Button btnCandy;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.TextBox txtMoney;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPay;
    }
}

