﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("VENDING MACHINE");
            double nickles = 0.05, demis = 0.1, quarters = 0.25, pennies = 0.01;
            double inputCoin;
            AcceptCoins acceptCoins = new AcceptCoins();
            
            Console.WriteLine("Enter the coin:" );
            inputCoin = Convert.ToDouble(Console.ReadLine());

             double currBal= acceptCoins.AcceptValidCoins(inputCoin);

            if ((currBal == nickles) || (currBal == demis) || (currBal == quarters))
                Console.WriteLine("Current Balance = " + currBal);
            else if (currBal == 0)
                Console.WriteLine("Insert the Coin");
            else if (currBal == pennies)
            { 
                acceptCoins.RejectCoins(pennies);
                Console.WriteLine("Coin Return");
            }
            else
                Console.WriteLine("Invalid Coin");

            Console.ReadKey();
        }
    }
}
