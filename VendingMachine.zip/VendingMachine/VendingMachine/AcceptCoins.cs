﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    class AcceptCoins
    {
        private static double _currBal;
        private double _coinReturn;
        public enum CoinsTypes
        {
            nickels,
            dimes,
            quarters,
            pennies
        }
        public double AcceptValidCoins(double coins)
        {
            CoinsTypes value = CoinsTypes.nickels;
            switch (value)
            {
                case CoinsTypes.nickels:
                    _currBal += coins;
                    break;
                case CoinsTypes.dimes:
                    _currBal += coins;
                    break;
                case CoinsTypes.quarters:
                    _currBal += coins;
                    break;
                case CoinsTypes.pennies:
                    _coinReturn += coins;
                    break;
            }
            return _currBal;
        }

        public void RejectCoins(double coins)
        {
            _coinReturn += coins;
        }

       
    }
}
