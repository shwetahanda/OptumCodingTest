﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Products
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        double total;
        private void btnCola_Click(object sender, EventArgs e)
        {
            total += 1.00;
        }

       

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (Convert.ToDouble(txtMoney.Text) == total)
            { 
                MessageBox.Show("THANK YOU");
                txtMoney.Text = "";
                total = 0;
                lblDisplay.Text = "";
            }
            else
            { 
                lblDisplay.Text = "The Total Amount to be Paid is:" + total.ToString();
                txtMoney.Focus();
            }
        }

        private void btnChips_Click(object sender, EventArgs e)
        {
            total += 0.50;
        }

        private void btnCandy_Click(object sender, EventArgs e)
        {
           total += 0.65;
        }
    }
}
